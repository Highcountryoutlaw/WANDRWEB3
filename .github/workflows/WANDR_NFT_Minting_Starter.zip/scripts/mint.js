const { ethers } = require("hardhat");

async function main() {
  const contractAddress = "YOUR_DEPLOYED_CONTRACT_ADDRESS";
  const wandr = await ethers.getContractAt("WandrNFT", contractAddress);
  const tx = await wandr.mint("ipfs://your-token-metadata-uri");
  await tx.wait();
  console.log("NFT minted!");
}

main().catch(console.error);
