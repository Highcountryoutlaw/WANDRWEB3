const hre = require("hardhat");

async function main() {
  const WandrNFT = await hre.ethers.getContractFactory("WandrNFT");
  const wandr = await WandrNFT.deploy();
  await wandr.deployed();
  console.log("Contract deployed to:", wandr.address);
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
